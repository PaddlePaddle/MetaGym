from rlschool import LiftSim

env = LiftSim()
state = env.reset()
while True:
    action = [1, 0, 1, 0, 1, 0, 1, 0]
    next_state, reward, done, _ = env.step(action)
