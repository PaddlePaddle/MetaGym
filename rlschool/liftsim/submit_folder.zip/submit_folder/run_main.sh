#!/bin/bash
. /opt/conda/bin/activate py3 # 激活环境，可选择使用py2（Python2.7）或者py3（Python3.6）
pip install -r requirements.txt # 安装requirements.txt文件中的依赖库
python main.py  # 自定义代码运行命令
